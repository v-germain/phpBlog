const admin = new Admin();
admin.displayComment();
admin.displayList();
admin.displayPost();